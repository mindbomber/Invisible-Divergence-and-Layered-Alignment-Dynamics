ATS / Invisible Divergence arXiv paper Overleaf project

Compile instructions:
1. Upload this ZIP to Overleaf.
2. Set main.tex as the root file.
3. Compile with pdfLaTeX.

Notes:
- All figures are native TikZ/PGFPlots inside main.tex.
- No external image files are required.
- The PDF included here was compiled locally from this source.
- Pilot-style numerical results are explicitly labeled as illustrative and should be replaced by real evaluation outputs before empirical submission claims.
